<?php
echo "The message has been sent!";
?>